function viewGraph(){
    $('.column').css('height','0');
    $('table tr').each(function(index) {
    var ha = $(this).children('td').eq(1).text();
    $('#col'+index).animate({height: ha}, 1500).html("<div>"+ha+"</div>");
    });
    }
    $(document).ready(function(){
    viewGraph();
    });